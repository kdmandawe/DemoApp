// <start id="mindreader_java" />
package com.samsung.samsunggottalent;

public interface MindReader {
  void interceptThoughts(String thoughts);

  String getThoughts();
}
// <end id="mindreader_java" />
