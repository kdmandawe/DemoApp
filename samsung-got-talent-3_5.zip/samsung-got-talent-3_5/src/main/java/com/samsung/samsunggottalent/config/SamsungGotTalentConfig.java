package com.samsung.samsunggottalent.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.samsung.samsunggottalent.Audience;
import com.samsung.samsunggottalent.ContestantIntroducer;
import com.samsung.samsunggottalent.Guitar;
import com.samsung.samsunggottalent.Instrument;
import com.samsung.samsunggottalent.Instrumentalist;
import com.samsung.samsunggottalent.Magician;
import com.samsung.samsunggottalent.Performer;
import com.samsung.samsunggottalent.Thinker;
import com.samsung.samsunggottalent.Volunteer;

@Configuration
@EnableAspectJAutoProxy
public class SamsungGotTalentConfig {

	@Bean
	public Performer eddie() {
		Performer eddie = new Instrumentalist();
		((Instrumentalist)eddie).setInstrument(guitar());
		return eddie;
	}
	
	@Bean
	public Instrument guitar() {
		Instrument instrument = new Guitar();
		return instrument;
	}
	
	@Bean
	public Audience audience() {
		Audience audience = new Audience();
		return audience;
	}
	
	@Bean
	public ContestantIntroducer contestantIntroducer() {
		ContestantIntroducer contestantIntroducer = new ContestantIntroducer();
		return contestantIntroducer;
	}
	
	@Bean
	public Thinker volunteer() {
		Thinker volunteer = new Volunteer();
		return volunteer;
	}
	
	@Bean Magician magician() {
		Magician magician = new Magician();
		return magician;
	}
}
