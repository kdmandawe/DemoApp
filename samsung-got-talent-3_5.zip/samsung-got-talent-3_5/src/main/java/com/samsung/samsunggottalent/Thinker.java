// <start id="thinker_java" />
package com.samsung.samsunggottalent;

public interface Thinker {
  void thinkOfSomething(String thoughts);
}
// <end id="thinker_java" />
