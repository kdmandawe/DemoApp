package com.samsung.samsunggottalent;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclareParents;

@Aspect
public class ContestantIntroducer {

  @DeclareParents( //<co id="co_declareParents"/>
      value = "com.samsung.samsunggottalent.Performer+", 
      defaultImpl = GraciousContestant.class)
  public static Contestant contestant;
}