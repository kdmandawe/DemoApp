package com.samsung.samsunggottalent;

public interface Performer {
  void perform() throws PerformanceException;
}
