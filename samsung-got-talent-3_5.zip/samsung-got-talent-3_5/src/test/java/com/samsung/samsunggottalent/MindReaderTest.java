package com.samsung.samsunggottalent;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.samsung.samsunggottalent.MindReader;
import com.samsung.samsunggottalent.Thinker;
import com.samsung.samsunggottalent.config.SamsungGotTalentConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SamsungGotTalentConfig.class)
public class MindReaderTest {
	
  @Autowired
  MindReader magician;

  @Autowired
  Thinker volunteer;

  // <start id="testMindReader" />
  @Test
  public void magicianShouldReadVolunteersMind() {
    volunteer.thinkOfSomething("Queen of Hearts");

    assertEquals("Queen of Hearts", magician.getThoughts());
  }
  // <end id="testMindReader" />
}
