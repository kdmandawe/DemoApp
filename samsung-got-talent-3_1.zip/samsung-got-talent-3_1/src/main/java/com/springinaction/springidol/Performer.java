package com.springinaction.springidol;

public interface Performer {
  void perform() throws PerformanceException;
}
