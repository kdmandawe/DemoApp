package com.samsung.samsunggottalent;

public interface Instrument {
  public void play();
}
