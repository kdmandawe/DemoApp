package com.samsung.samsunggottalent;

public interface MindReader {
  void interceptThoughts(String thoughts);

  String getThoughts();
}