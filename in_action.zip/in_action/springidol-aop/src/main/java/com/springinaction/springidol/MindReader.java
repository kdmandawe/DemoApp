package com.springinaction.springidol;

public interface MindReader {
  void interceptThoughts(String thoughts);

  String getThoughts();
}