package com.springinaction.springidol;

public interface Thinker {
  void thinkOfSomething(String thoughts);
}