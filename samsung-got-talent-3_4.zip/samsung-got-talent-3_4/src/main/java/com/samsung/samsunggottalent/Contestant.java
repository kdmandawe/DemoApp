package com.samsung.samsunggottalent;

public interface Contestant {
  void receiveAward();
}