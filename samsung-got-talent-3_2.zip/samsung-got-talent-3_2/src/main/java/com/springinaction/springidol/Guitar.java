package com.springinaction.springidol;

public class Guitar implements Instrument {
  public void play() {
	try {
		Thread.sleep(2000);
//		System.out.println("Strum strum strum");
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
  }
}
